import React from 'react';
import LifecycleComponent from './LifecycleComponent';

function App() {
  return (
    <div className="App">
      <h1>My App</h1>
      <LifecycleComponent />
    </div>
  );
}

export default App;
