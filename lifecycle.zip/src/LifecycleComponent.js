import React, { Component } from 'react';
import './LifecycleComponent.css';


class LifecycleComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0
    };
    console.log('Constructor called');
  }

  componentDidMount() {
    console.log('Component did mount');
  }

  componentDidUpdate(prevProps, prevState) {
    console.log('Component did update');
  }

  componentWillUnmount() {
    console.log('Component will unmount');
  }

  handleClick = () => {
    this.setState(prevState => ({
      counter: prevState.counter + 1
    }));
  };

  render() {
    console.log('Render called');
    return (
      <div>
        <h2>Lifecycle Component</h2>
        <p>Counter: {this.state.counter}</p>
        <button onClick={this.handleClick}>Increment Counter</button>
      </div>
    );
  }
}

export default LifecycleComponent;
